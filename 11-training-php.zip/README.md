# php-training
* Repository: https://github.com/tailieuweb/training-php

## System requirements
* Apache: 2.4
* MySQL: 5.7 ; MariaDB: 10.x
* PHP: 7.x, 8.x
* Wamp/Xampp

# Features
- CRUD user